package notifications;

public class Response {

    private String success;
}
