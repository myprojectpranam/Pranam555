package com.example.pranam555.ui;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.pranam555.ChatActivity;
import com.example.pranam555.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class NewGroupChatActivity extends AppCompatActivity {

    private String groupId;
    String myGroupRole="";
    private Toolbar toolbar;
    private CircleImageView groupChatIcon;
    private TextView txtGroupChatTitle;
    private ImageButton imgAttachFile,btnSendGroupChatMessage;
    private EditText edtGroupChatMessages;
    private RecyclerView groupChatRecyclerView;
    private ArrayList<NewGroupModelChat> groupChatArrayList;
    private ArrayList<NewGroupModelChat> participants;
    private AdapterGroupChat adapterGroupChat;
    String fileChecker = "",myUrl="";
    private ProgressDialog loadingBar;
    private Uri fileUri;
    private DatabaseReference databaseReference;
    private StorageTask uploadTask;
    String allParticipantsUids;

    private FirebaseAuth mAuth;
    String currentUserID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_group_chat);


        loadingBar = new ProgressDialog(this);
        groupChatIcon = findViewById(R.id.groupChatIcon);
        txtGroupChatTitle = findViewById(R.id.txtGroupChatTitle);
        imgAttachFile = findViewById(R.id.imgAttachFile);
        edtGroupChatMessages = findViewById(R.id.edtGroupChatMessages);
        btnSendGroupChatMessage = findViewById(R.id.btnSendGroupChatMessage);
        groupChatRecyclerView = findViewById(R.id.groupChatRecyclerView);
        databaseReference = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        currentUserID = mAuth.getCurrentUser().getUid();


        toolbar = findViewById(R.id.group_chat_activity_toolbar);
        setSupportActionBar(toolbar);
        groupId = getIntent().getExtras().getString("groupId");

        mAuth = FirebaseAuth.getInstance();

        loadGroupInfo();
        loadGroupMessages();
        loadMyGroupRole();

        btnSendGroupChatMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String typedMessage = edtGroupChatMessages.getText().toString().trim();

                sendMessage(typedMessage);

                if (typedMessage.isEmpty()){

                    Toast.makeText(NewGroupChatActivity.this,"Can't send empty message",Toast.LENGTH_SHORT).show();
                }else {


                }

                edtGroupChatMessages.setText("");


            }
        });

        imgAttachFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendFiles();
            }
        });


    }

    private void loadMyGroupRole(){

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Groups");
        databaseReference.child(groupId).child("Participants")
                .orderByChild("uid").equalTo(mAuth.getCurrentUser().getUid())
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        for (DataSnapshot dataSnapshot1: dataSnapshot.getChildren()){

                            myGroupRole = dataSnapshot1.child("role").getValue().toString();
                            invalidateOptionsMenu();
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    private void sendMessage(String message){

        String timeStamp = "" + System.currentTimeMillis();
        //Creating database when message is sent
        HashMap<String,Object> messageBody = new HashMap<>();
        messageBody.put("sender",mAuth.getCurrentUser().getUid());
        messageBody.put("message",message);
        messageBody.put("timestamp",timeStamp);
        messageBody.put("type","text");

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Groups");
        databaseReference.child(groupId).child("GpMessages").child(timeStamp)
                .setValue(messageBody).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful()){


                }
            }
        });

    }

    private void sendFiles(){


        CharSequence options [] = new CharSequence[3];

        options[0] = "Images";
        options[1] = "PDF Files";
        options[2] = "Word Files";

        AlertDialog.Builder builder = new AlertDialog.Builder(NewGroupChatActivity.this);
        builder.setTitle("Select file");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int position) {

                if (position == 0){

                    fileChecker = "image";


                    //Moving user to gallery to select pic to send
                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    //Moving user to gallery to select pic to send
                    intent.setType("image/*");
                    startActivityForResult(intent.createChooser(intent,"Select image"),1000);


                }if (position == 1){

                    fileChecker = "pdf";

                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    intent.setType("application/pdf");
                    startActivityForResult(intent.createChooser(intent,"Select pdf file"),1000);


                }if (position == 2){


                    fileChecker = "docx";

                    Intent intent = new Intent();
                    intent.setAction(Intent.ACTION_GET_CONTENT);
                    intent.setType("application/msword");
                    startActivityForResult(intent.createChooser(intent,"Select word file"),1000);


                }

            }
        });

        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1000 && resultCode == RESULT_OK && data!=null && data.getData()!=null){

            loadingBar.setTitle("Sending file");
            loadingBar.setMessage("Please wait...");
            loadingBar.setCanceledOnTouchOutside(false);
            loadingBar.show();

            //Getting image from gallery and storing it to fileUri
            fileUri = data.getData();

            if (!fileChecker.equals("image")){

                StorageReference storageReference = FirebaseStorage.getInstance().getReference("Group Document Files");


                //Creating a key in the database for every messages///
//                DatabaseReference userMessagesKeyReference = databaseReference.child("Groups")
//                        .child(groupId).push();
//                String messagePushedID = userMessagesKeyReference.getKey();

                String timeStamp = "" + System.currentTimeMillis();

                StorageReference filePath = storageReference.child(timeStamp + "." + fileChecker);

                filePath.putFile(fileUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                        filePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {


                                String downloadUrl = uri.toString();

                                Map messageDocseBody = new HashMap();
                                messageDocseBody.put("message",downloadUrl);
                                messageDocseBody.put("name",fileUri.getLastPathSegment());//This is same name url in the storage
                                messageDocseBody.put("sender",currentUserID);
                                messageDocseBody.put("timestamp",timeStamp);
                                messageDocseBody.put("type",fileChecker);

                                Map messageDocsBodyDetails =new HashMap();
                                messageDocsBodyDetails.put(timeStamp,messageDocseBody);

                                DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Groups").child(groupId).child("GpMessages");
                                databaseReference.updateChildren(messageDocsBodyDetails);
                                loadingBar.dismiss();
                            }
                        }).addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                                loadingBar.dismiss();
                                Toast.makeText(NewGroupChatActivity.this,e.getMessage(),Toast.LENGTH_SHORT).show();

                            }
                        });

                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {

                        double progess = (100.0 * snapshot.getBytesTransferred())/snapshot.getTotalByteCount();
                        loadingBar.setMessage((int) progess + " % uploading....");
                    }
                });


            }else if (fileChecker.equals("image")){

                //Creating a separate folder of image which user is sending to other users
                StorageReference storageReference = FirebaseStorage.getInstance().getReference("Group Image File");

                //Creating a nod directly by the name of Messages in the database

                //Creating a key in the database for every messages///
//                DatabaseReference userMessagesKeyReference = databaseReference.child("Groups")
//                        .child(groupId).push();
//                String messagePushedID = userMessagesKeyReference.getKey();

                String timeStamp = "" + System.currentTimeMillis();

                StorageReference filePath = storageReference.child(timeStamp + "." + "jpg");

                uploadTask = filePath.putFile(fileUri);

                uploadTask.continueWithTask(new Continuation() {
                    @Override
                    public Object then(@NonNull Task task) throws Exception {

                        if (!task.isSuccessful()){

                            throw task.getException();
                        }

                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener() {
                    @Override
                    public void onComplete(@NonNull Task task) {

                        if (task.isSuccessful()){

                            //Getting url of the image so that it shows to the other user
                            Uri downloadUrl = (Uri) task.getResult();
                            myUrl = downloadUrl.toString();
                            String timeStamp = "" + System.currentTimeMillis();


                            Map messageImageBody = new HashMap();
                            messageImageBody.put("message",myUrl);
                            messageImageBody.put("name",fileUri.getLastPathSegment());//This is same name url in the storage
                            messageImageBody.put("sender",currentUserID);
                            messageImageBody.put("timestamp",timeStamp);
                            messageImageBody.put("type",fileChecker);
                            //   messageImageBody.put("to",groupId);
                            //  messageImageBody.put("messageID",messagePushedID);


                            Map messageImageBodyDetails =new HashMap();
                            messageImageBodyDetails.put(timeStamp,messageImageBody);

                            DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Groups").child(groupId).child("GpMessages");
                            databaseReference.updateChildren(messageImageBodyDetails).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(@NonNull Task task) {

                                    if (task.isSuccessful()){

                                        loadingBar.dismiss();

                                        Toast.makeText(NewGroupChatActivity.this,"Successful",Toast.LENGTH_SHORT).show();
                                    }else {

                                        loadingBar.dismiss();
                                        Toast.makeText(NewGroupChatActivity.this,"Error",Toast.LENGTH_SHORT).show();

                                    }
                                    edtGroupChatMessages.setText("");
                                }
                            });


                        }

                    }
                });


            }else {

                loadingBar.dismiss();

                Toast.makeText(NewGroupChatActivity.this,"Nothing Selected",Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void loadGroupInfo(){

        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Groups");
        databaseReference.orderByChild("groupId").equalTo(groupId).addValueEventListener
                (new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){

                            //Getting details of group to show it on group toolbar

                            String groupTitle = (String) dataSnapshot1.child("groupTitle").getValue();
                            String groupDescription = (String) dataSnapshot1.child("groupDescriptiom").getValue();
                            String groupIcon = (String) dataSnapshot1.child("groupIcon").getValue();
                            String timestamp = (String) dataSnapshot1.child("timestamp").getValue();
                            String createdBy = (String) dataSnapshot1.child("createdBy").getValue();

                            txtGroupChatTitle.setText(groupTitle);

                            try {

                                Picasso.get().load(groupIcon).placeholder(R.drawable.profile_image).into(groupChatIcon);

                            }catch (Exception e){
                                groupChatIcon.setImageResource(R.drawable.group_blue);
                            }

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
    private void loadGroupMessages(){

        groupChatArrayList = new ArrayList<>();
        participants = new ArrayList<>();


        //Retrieving the group message on the screen with the help of adapter
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Groups");
        databaseReference.child(groupId).child("GpMessages")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        groupChatArrayList.clear();
                        participants.clear();

                        for (DataSnapshot dataSnapshot1:dataSnapshot.getChildren()){
                            // NewGroupModelChat has message,sender,timestamp,type;
                            NewGroupModelChat model = dataSnapshot1.getValue(NewGroupModelChat.class);
                            //Adding these items to the arraylist
                            groupChatArrayList.add(model);
                        }


                        adapterGroupChat = new AdapterGroupChat(NewGroupChatActivity.this,groupChatArrayList,groupId);
                        groupChatRecyclerView.setAdapter(adapterGroupChat);
                    }



                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main,menu);
        menu.findItem(R.id.group_info).setVisible(true);
        menu.findItem(R.id.find_friends).setVisible(false);
        menu.findItem(R.id.settings).setVisible(false);
        menu.findItem(R.id.logout).setVisible(false);



        if (myGroupRole.equals("creator")|| myGroupRole.equals("admin")){

            menu.findItem(R.id.add_Participant).setVisible(true);
        }else {

            menu.findItem(R.id.add_Participant).setVisible(false );

        }
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id==R.id.add_Participant){

            Intent intent = new Intent(NewGroupChatActivity.this,NewGroupParticipantsAddActivity.class);
            intent.putExtra("groupId",groupId);
            startActivity(intent);

        }else if (id==R.id.group_info){

            Intent moveToGroupInfoActivity = new Intent(NewGroupChatActivity.this,GroupInfoActivity.class);
            moveToGroupInfoActivity.putExtra("groupId",groupId);
            startActivity(moveToGroupInfoActivity);

        }
        return super.onOptionsItemSelected(item);
    }
}

